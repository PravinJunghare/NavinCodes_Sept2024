package com.qa.hubspot.page;

import com.qa.hubspot.base.BasePage;

public class DealsPage extends BasePage{
	
	public DealsPage(){
		System.out.println("deals page const....");
		
	}
	
	

}
